# Basic Zeppelin + Scala

## Simple setup guide
1. `docker-compose -f "scala_zeppelin/docker-compose.yml" up -d --build`
2. Point your browser to http://localhost:8080/
3. Import note > Select JSON File/IPYNB File > open /zeppelin/notes/hello_scala.zpln
4. To create other notebooks in scala select the spark environment
5. Have fun!


